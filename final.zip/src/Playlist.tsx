import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/Playlist.module.css";

export const Playlist: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameLinkClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onButtonLinkClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onButtonClick = useCallback(() => {
    navigate("/db");
  }, [navigate]);

  const onButton3Click = useCallback(() => {
    navigate("/playlist");
  }, [navigate]);

  return (
    <main className={styles.playlistMain}>
      <div className={styles.groupDiv}>
        <img className={styles.vectorIcon} alt="" src="vector.svg" />
        <div className={styles.frameDiv}>
          <div className={styles.topNavDiv}>
            <div className={styles.topNavDiv1}>
              <div className={styles.topNavDiv2}>
                <a
                  className={styles.frameA}
                  href="/home-page"
                  onClick={onFrameLinkClick}
                >
                  <img
                    className={styles.vector2Icon}
                    alt=""
                    src="vector-2.svg"
                  />
                </a>
                <header className={styles.horizontalTabsHeader}>
                  <header className={styles.tabsHeader}>
                    <a
                      className={styles.buttonA}
                      href="/home-page"
                      onClick={onButtonLinkClick}
                    >
                      <button className={styles.labeltextButton}>Home</button>
                    </a>
                    <button className={styles.button} onClick={onButtonClick}>
                      <button className={styles.labeltextButton}>
                        Database
                      </button>
                    </button>
                    <button className={styles.button2} autoFocus>
                      <div className={styles.labeltext2Div}>Shuffle</div>
                    </button>
                    <button
                      className={styles.button3}
                      autoFocus
                      onClick={onButton3Click}
                    >
                      <div className={styles.labelTextDiv}>Playlist</div>
                    </button>
                    <a className={styles.button4A} href="/advsearch">
                      <div className={styles.labeltext4Div}>
                        Advanced Search
                      </div>
                    </a>
                  </header>
                </header>
              </div>
            </div>
          </div>
          <div className={styles.frameDiv1}>
            <div className={styles.headersDiv}>
              <div className={styles.frameDiv2}>
                <img
                  className={styles.rectangleIcon}
                  alt=""
                  src="rectangle-896.svg"
                />
                <div className={styles.frameDiv3}>
                  <main className={styles.main}>
                    <div className={styles.component1Div}>
                      <div className={styles.rowsDiv}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>1</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <div className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>2</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <div className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>3</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <div className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>4</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <div className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>5</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <div className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>6</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <div className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>7</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <div className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>8</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <div className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv}>9</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv1}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </div>
                      <form className={styles.rowsForm}>
                        <div className={styles.groupDiv1}>
                          <div className={styles.frameDiv4}>
                            <div className={styles.frameDiv5}>
                              <div className={styles.activeDiv}>
                                <div className={styles.checkFrameDiv}>
                                  <div className={styles.checkboxDiv} />
                                </div>
                              </div>
                              <div className={styles.div}>
                                <div className={styles.rowNumDiv9}>10</div>
                              </div>
                            </div>
                            <div className={styles.fieldVarientsDiv18}>
                              <div className={styles.inputdisabledDiv}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.nameDiv18}>
                                    <p className={styles.blankLineP}>&nbsp;</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.fieldVarientsDiv19}>
                            <div className={styles.inputdisabledDiv}>
                              <div className={styles.frameDiv6}>
                                <div className={styles.nameDiv18}>
                                  <p className={styles.blankLineP}>&nbsp;</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img
                          className={styles.frameIcon}
                          alt=""
                          src="frame-2441.svg"
                        />
                      </form>
                      <img
                        className={styles.groupIcon}
                        alt=""
                        src="group-2443.svg"
                      />
                    </div>
                  </main>
                </div>
              </div>
              <header className={styles.frameHeader}>
                <div className={styles.addUpTo10SongsAndWeWill}>
                  Add up to 10 songs and we will generate some jams for you
                </div>
              </header>
              <div className={styles.frameDiv44}>
                <div className={styles.frameDiv45}>
                  <div className={styles.groupDiv11}>
                    <div className={styles.fieldVarientsDiv20}>
                      <div className={styles.inputdisabledDiv}>
                        <div className={styles.frameDiv46}>
                          <div className={styles.div10}>#</div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.fieldVarientsDiv21}>
                      <div className={styles.trackNameDiv}>Track Name</div>
                    </div>
                  </div>
                  <div className={styles.fieldVarientsDiv22}>
                    <div className={styles.artistNameDiv}>Artist Name</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.frameDiv47} />
          </div>
        </div>
      </div>
    </main>
  );
};
