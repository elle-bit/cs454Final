import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/AdvSearch.module.css";

export const AdvSearch: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameLinkClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onButtonLinkClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onButtonClick = useCallback(() => {
    navigate("/database");
  }, [navigate]);

  const onButton3Click = useCallback(() => {
    navigate("/playlist");
  }, [navigate]);

  return (
    <div className={styles.advSearchDiv}>
      <div className={styles.groupDiv}>
        <img className={styles.vectorIcon} alt="" src="vector2.svg" />
        <div className={styles.frameDiv}>
          <div className={styles.topNavDiv}>
            <div className={styles.topNavDiv1}>
              <div className={styles.topNavDiv2}>
                <a
                  className={styles.frameA}
                  href="/home-page"
                  onClick={onFrameLinkClick}
                >
                  <img
                    className={styles.vector2Icon}
                    alt=""
                    src="vector-2.svg"
                  />
                </a>
                <header className={styles.horizontalTabsHeader}>
                  <header className={styles.tabsHeader}>
                    <a
                      className={styles.buttonA}
                      href="/home-page"
                      onClick={onButtonLinkClick}
                    >
                      <button className={styles.labeltextButton}>Home</button>
                    </a>
                    <button className={styles.button} onClick={onButtonClick}>
                      <button className={styles.labeltextButton}>
                        Database
                      </button>
                    </button>
                    <button className={styles.button2} autoFocus>
                      <div className={styles.labeltext2Div}>Shuffle</div>
                    </button>
                    <button
                      className={styles.button2}
                      autoFocus
                      onClick={onButton3Click}
                    >
                      <div className={styles.labeltext2Div}>Playlist</div>
                    </button>
                    <button className={styles.button4}>
                      <div className={styles.labelTextDiv1}>
                        Advanced Search
                      </div>
                    </button>
                  </header>
                </header>
              </div>
            </div>
          </div>
          <div className={styles.frameDiv1}>
            <div className={styles.frameDiv2} />
          </div>
        </div>
        <div className={styles.frameDiv3}>
          <div className={styles.frameDiv4}>
            <main className={styles.main} />
          </div>
        </div>
      </div>
    </div>
  );
};
