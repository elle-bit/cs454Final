import { FunctionComponent } from "react";
import styles from "./css/DesktopMenu1.module.css";

type DesktopMenu1Type = {
  onClose?: () => void;
};

export const DesktopMenu1: FunctionComponent<DesktopMenu1Type> = ({
  onClose,
}) => {
  return (
    <div className={styles.desktopMenuDiv}>
      <div className={styles.artisDiv}>
        <div className={styles.listItem9}>
          <div className={styles.divider}>
            <div className={styles.divider1} />
          </div>
          <div className={styles.listItemDiv}>
            <div className={styles.trailingItemsDiv}>
              <div className={styles.trailingTextDiv}>Trailing text</div>
              <img
                className={styles.iconsarrowRight24px}
                alt=""
                src="iconsarrow-right-24px.svg"
              />
            </div>
            <div className={styles.textDiv}>Descending</div>
          </div>
        </div>
      </div>
      <div className={styles.artisDiv}>
        <div className={styles.listItem9}>
          <div className={styles.divider}>
            <div className={styles.divider1} />
          </div>
          <div className={styles.listItemDiv}>
            <div className={styles.trailingItemsDiv}>
              <div className={styles.trailingTextDiv}>Trailing text</div>
              <img
                className={styles.iconsarrowRight24px1}
                alt=""
                src="iconsarrow-right-24px1.svg"
              />
            </div>
            <div className={styles.textDiv}>Acsending</div>
          </div>
        </div>
      </div>
    </div>
  );
};
