import { FunctionComponent, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { DesktopMenu1 } from "./DesktopMenu1";
import { PortalPopup } from "./PortalPopup";
import styles from "./css/Database.module.css";

export const Database: FunctionComponent = () => {
  const [isDesktopMenuOpen, setDesktopMenuOpen] = useState(false);
  const navigate = useNavigate();

  const openDesktopMenu = useCallback(() => {
    setDesktopMenuOpen(true);
  }, []);

  const closeDesktopMenu = useCallback(() => {
    setDesktopMenuOpen(false);
  }, []);

  const onFrameLinkClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onButtonLinkClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onButton1Click = useCallback(() => {
    navigate("/db");
  }, [navigate]);

  const onButton3LinkClick = useCallback(() => {
    navigate("/frame-811331");
  }, [navigate]);

  return (
    <>
      <div className={styles.databaseDiv}>
        <div className={styles.groupDiv}>
          <img className={styles.vectorIcon} alt="" src="vector3.svg" />
          <main className={styles.frameMain}>
            <main className={styles.contentMain}>
              <div className={styles.topFormDiv}>
                <div className={styles.topFormDiv1}>
                  <input
                    className={styles.textfieldBuildingBlock}
                    type="text"
                  />
                  <div className={styles.frameDiv}>
                    <img
                      className={styles.buttonIcon}
                      alt=""
                      src="button.svg"
                      onClick={openDesktopMenu}
                    />
                    <div className={styles.filterDiv}>Filter</div>
                  </div>
                </div>
                <img
                  className={styles.rectangleIcon}
                  alt=""
                  src="rectangle-897.svg"
                />
              </div>
              <fieldset className={styles.tableFieldset}>
                <div className={styles.headerDiv}>
                  <img
                    className={styles.rectangleIcon1}
                    alt=""
                    src="rectangle-8961.svg"
                  />
                  <div className={styles.frameDiv1}>
                    <div className={styles.title1Div}>
                      <div className={styles.numberDiv}>
                        <div className={styles.frameDiv2}>
                          <div className={styles.div}>#</div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.title2Div}>
                      <div className={styles.trackDiv}>
                        <div className={styles.frameDiv2}>
                          <div className={styles.frameDiv3}>
                            <div className={styles.trackDiv2}>Track</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.title2Div}>
                      <div className={styles.artistDiv}>
                        <div className={styles.imgDiv}>
                          <div className={styles.textDiv}>
                            <div className={styles.frameDiv4}>
                              <div className={styles.frameDiv5}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.trackDiv3}>Artist</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.title2Div}>
                      <div className={styles.albumDiv}>
                        <div className={styles.albumDiv1}>
                          <div className={styles.textDiv1}>
                            <div className={styles.frameDiv4}>
                              <div className={styles.frameDiv8}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.trackDiv4}>Album</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.title2Div}>
                      <div className={styles.imageDiv}>
                        <div className={styles.imgDiv}>
                          <div className={styles.textDiv1}>
                            <div className={styles.frameDiv4}>
                              <div className={styles.frameDiv8}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.trackDiv4}>Image</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.title2Div}>
                      <div className={styles.genreDiv}>
                        <div className={styles.imgDiv}>
                          <div className={styles.textDiv1}>
                            <div className={styles.frameDiv4}>
                              <div className={styles.frameDiv8}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.trackDiv4}>Genre</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.title1Div}>
                      <div className={styles.ratingDiv}>
                        <div className={styles.imgDiv}>
                          <div className={styles.textDiv4}>
                            <div className={styles.frameDiv4}>
                              <div className={styles.frameDiv17}>
                                <div className={styles.frameDiv6}>
                                  <div className={styles.trackDiv4}>Score</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <img
                      className={styles.title8Icon}
                      alt=""
                      src="title8.svg"
                    />
                    <img
                      className={styles.title8Icon}
                      alt=""
                      src="title9.svg"
                    />
                  </div>
                </div>
                <div className={styles.frameDiv19}>
                  <main className={styles.groupMain}>
                    <div className={styles.rowsoverlayDiv}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <div className={styles.moreDiv}>
                        <button className={styles.moreButton}>
                          <img className={styles.icon} alt="" src="icon.svg" />
                        </button>
                      </div>
                    </div>
                    <div className={styles.rowsoverlayDiv1}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv2}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image2.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more1.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv3}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more2.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv4}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more3.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv5}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more4.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv6}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more5.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv7}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more6.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv8}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more7.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv9}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more8.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv10}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" src="more9.svg" />
                    </div>
                    <div className={styles.rowsoverlayDiv11}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img
                        className={styles.title8Icon}
                        alt=""
                        src="image.svg"
                      />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img
                        className={styles.moreIcon}
                        alt=""
                        src="more10.svg"
                      />
                    </div>
                    <div className={styles.rowsoverlayDiv12}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img className={styles.title8Icon} alt="" />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" />
                    </div>
                    <div className={styles.rowsoverlayDiv13}>
                      <div className={styles.numberDiv1}>
                        <div className={styles.frameDiv20}>
                          <div className={styles.div}>1</div>
                        </div>
                      </div>
                      <div className={styles.trackDiv8}>
                        <div className={styles.textDiv5}>
                          <div className={styles.frameDiv21}>
                            <div className={styles.frameDiv22}>
                              <div className={styles.frameDiv23}>
                                <div className={styles.trackDiv9}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.frameDiv20}>
                              <div className={styles.artistDiv3}>Artist</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.artistDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv24}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Album</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img className={styles.title8Icon} alt="" />
                      <div className={styles.genreDiv2}>
                        <div className={styles.columnDiv}>
                          <div className={styles.frameDiv28}>
                            <div className={styles.columnDiv}>
                              <div className={styles.artistDiv3}>Genre</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.ratingDiv2}>
                        <div className={styles.frameDiv28}>
                          <div className={styles.frameDiv31}>
                            <div className={styles.div2}>65</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.emptyDiv} />
                      <img className={styles.moreIcon} alt="" />
                    </div>
                    <div className={styles.rowsoverlayDiv14}>
                      <img className={styles.rectangleIcon1} alt="" />
                      <div className={styles.frameDiv1}>
                        <div className={styles.title1Div}>
                          <div className={styles.numberDiv}>
                            <div className={styles.frameDiv2}>
                              <div className={styles.div}>#</div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.title2Div}>
                          <div className={styles.trackDiv}>
                            <div className={styles.frameDiv2}>
                              <div className={styles.frameDiv3}>
                                <div className={styles.trackDiv2}>Track</div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.title2Div}>
                          <div className={styles.artistDiv}>
                            <div className={styles.imgDiv}>
                              <div className={styles.textDiv}>
                                <div className={styles.frameDiv4}>
                                  <div className={styles.frameDiv5}>
                                    <div className={styles.frameDiv6}>
                                      <div className={styles.trackDiv3}>
                                        Artist
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.title2Div}>
                          <div className={styles.albumDiv}>
                            <div className={styles.albumDiv1}>
                              <div className={styles.textDiv1}>
                                <div className={styles.frameDiv4}>
                                  <div className={styles.frameDiv8}>
                                    <div className={styles.frameDiv6}>
                                      <div className={styles.trackDiv4}>
                                        Album
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.title2Div}>
                          <div className={styles.imageDiv}>
                            <div className={styles.imgDiv}>
                              <div className={styles.textDiv1}>
                                <div className={styles.frameDiv4}>
                                  <div className={styles.frameDiv8}>
                                    <div className={styles.frameDiv6}>
                                      <div className={styles.trackDiv4}>
                                        Image
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.title2Div}>
                          <div className={styles.genreDiv}>
                            <div className={styles.imgDiv}>
                              <div className={styles.textDiv1}>
                                <div className={styles.frameDiv4}>
                                  <div className={styles.frameDiv8}>
                                    <div className={styles.frameDiv6}>
                                      <div className={styles.trackDiv4}>
                                        Genre
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.title1Div}>
                          <div className={styles.ratingDiv}>
                            <div className={styles.imgDiv}>
                              <div className={styles.textDiv1}>
                                <div className={styles.frameDiv4}>
                                  <div className={styles.frameDiv8}>
                                    <div className={styles.frameDiv6}>
                                      <div className={styles.trackDiv4}>
                                        Score
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <img className={styles.title8Icon} alt="" />
                        <img className={styles.title8Icon} alt="" />
                      </div>
                    </div>
                  </main>
                </div>
              </fieldset>
              <div className={styles.paginationDiv}>
                <div className={styles.buttonDiv}>
                  <div className={styles.valueDiv}>Previous</div>
                </div>
                <div className={styles.pageListDiv}>
                  <div className={styles.tabsDiv}>
                    <div className={styles.valueDiv1}>1</div>
                  </div>
                  <div className={styles.tabsDiv}>
                    <div className={styles.valueDiv1}>...</div>
                  </div>
                  <button className={styles.tabsButton}>
                    <div className={styles.valueDiv3}>10</div>
                  </button>
                  <div className={styles.tabsDiv}>
                    <div className={styles.valueDiv1}>11</div>
                  </div>
                  <div className={styles.tabsDiv3}>
                    <div className={styles.valueDiv5}>12</div>
                  </div>
                  <div className={styles.tabsDiv}>
                    <div className={styles.valueDiv1}>13</div>
                  </div>
                  <div className={styles.tabsDiv}>
                    <div className={styles.valueDiv1}>14</div>
                  </div>
                  <div className={styles.tabsDiv}>
                    <div className={styles.valueDiv1}>15</div>
                  </div>
                  <button className={styles.tabsButton1}>
                    <div className={styles.valueDiv3}>16</div>
                  </button>
                  <button className={styles.tabsButton1}>
                    <div className={styles.valueDiv3}>...</div>
                  </button>
                  <div className={styles.tabsDiv}>
                    <div className={styles.valueDiv1}>26</div>
                  </div>
                </div>
                <div className={styles.buttonDiv1}>
                  <div className={styles.valueDiv}>Next</div>
                </div>
              </div>
            </main>
          </main>
          <div className={styles.frameDiv206}>
            <div className={styles.topNavDiv}>
              <div className={styles.topNavDiv1}>
                <div className={styles.topNavDiv2}>
                  <a
                    className={styles.frameA}
                    href="/home-page"
                    onClick={onFrameLinkClick}
                  >
                    <img
                      className={styles.vector2Icon}
                      alt=""
                      src="vector-2.svg"
                    />
                  </a>
                  <header className={styles.horizontalTabsHeader}>
                    <header className={styles.tabsHeader}>
                      <a
                        className={styles.buttonA}
                        href="/home-page"
                        onClick={onButtonLinkClick}
                      >
                        <button className={styles.labeltextButton}>Home</button>
                      </a>
                      <button
                        className={styles.button}
                        onClick={onButton1Click}
                      >
                        <button className={styles.labelTextButton}>
                          Database
                        </button>
                      </button>
                      <button className={styles.button2} autoFocus>
                        <div className={styles.labeltext2Div}>Shuffle</div>
                      </button>
                      <a
                        className={styles.button3A}
                        onClick={onButton3LinkClick}
                      >
                        <div className={styles.labeltext3Div}>Playlist</div>
                      </a>
                      <a className={styles.button4A} href="/advsearch">
                        <div className={styles.labeltext3Div}>
                          Advanced Search
                        </div>
                      </a>
                    </header>
                  </header>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {isDesktopMenuOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeDesktopMenu}
        >
          <DesktopMenu1 onClose={closeDesktopMenu} />
        </PortalPopup>
      )}
    </>
  );
};
