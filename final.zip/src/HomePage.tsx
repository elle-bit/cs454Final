import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/HomePage.module.css";

export const HomePage: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameLinkClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onButtonLinkClick = useCallback(() => {
    navigate("/database");
  }, [navigate]);

  const onButton3LinkClick = useCallback(() => {
    navigate("/frame-811331");
  }, [navigate]);

  const onButton7ContainerClick = useCallback(() => {
    navigate("/playlist");
  }, [navigate]);

  return (
    <div className={styles.homePageDiv}>
      <div className={styles.groupDiv}>
        <img className={styles.vectorIcon} alt="" src="vector1.svg" />
        <div className={styles.frameDiv}>
          <div className={styles.topNavDiv}>
            <div className={styles.topNavDiv1}>
              <div className={styles.topNavDiv2}>
                <a
                  className={styles.frameA}
                  href="/home-page"
                  onClick={onFrameLinkClick}
                >
                  <img
                    className={styles.vector2Icon}
                    alt=""
                    src="vector-2.svg"
                  />
                </a>
                <header className={styles.horizontalTabsHeader}>
                  <header className={styles.tabsHeader}>
                    <button className={styles.button}>
                      <button className={styles.labelTextButton}>Home</button>
                    </button>
                    <a
                      className={styles.buttonA}
                      href="/database"
                      onClick={onButtonLinkClick}
                    >
                      <button className={styles.labelTextButton1}>
                        Database
                      </button>
                    </a>
                    <button className={styles.button2} autoFocus>
                      <div className={styles.labeltext2Div}>Shuffle</div>
                    </button>
                    <a className={styles.button3A} onClick={onButton3LinkClick}>
                      <div className={styles.labeltext3Div}>Playlist</div>
                    </a>
                    <a className={styles.button4A} href="/advsearch">
                      <div className={styles.labeltext3Div}>
                        Advanced Search
                      </div>
                    </a>
                  </header>
                </header>
              </div>
            </div>
          </div>
          <div className={styles.frame811332Div}>
            <main className={styles.main}>
              <img className={styles.vector3Icon} alt="" src="vector-3.svg" />
              <div className={styles.frameDiv1}>
                <div className={styles.textfieldBuildingBlock}>
                  <div className={styles.frame8113442Div}>
                    <img
                      className={styles.leadingIcon}
                      alt=""
                      src="leading.svg"
                    />
                    <input className={styles.textField2Input} type="text" />
                    <img
                      className={styles.trailingIcon}
                      alt=""
                      src="trailing.svg"
                    />
                  </div>
                </div>
                <button className={styles.button5} autoFocus>
                  <div className={styles.labeltext5Div}>Advanced Search</div>
                </button>
              </div>
              <div className={styles.frameDiv2}>
                <b className={styles.theStoryBehindTheMusic}>
                  The story behind the music...
                </b>
              </div>
            </main>
          </div>
          <div className={styles.frameDiv3}>
            <div className={styles.horizontalcardDiv}>
              <div className={styles.contentDiv}>
                <div className={styles.frameDiv4}>
                  <div className={styles.textDiv}>
                    <b className={styles.headerB}>
                      <span className={styles.headerTxtSpan}>
                        <p className={styles.advancedP}>Advanced </p>
                        <p className={styles.searchP}>search</p>
                      </span>
                    </b>
                    <div className={styles.subheadDiv}>
                      find exactly what you’re looking for
                    </div>
                  </div>
                </div>
                <div className={styles.frameDiv5}>
                  <a className={styles.button6A} href="/advsearch">
                    <button className={styles.statelayerButton} autoFocus>
                      <img className={styles.icons} alt="" src="icons.svg" />
                    </button>
                  </a>
                </div>
              </div>
              <div className={styles.frameDiv6}>
                <img
                  className={styles.frameIcon}
                  alt=""
                  src="frame-811308.svg"
                />
              </div>
            </div>
            <div className={styles.horizontalcard2Div}>
              <div className={styles.contentDiv}>
                <div className={styles.frameDiv4}>
                  <div className={styles.textDiv1}>
                    <b className={styles.headerB}>
                      <span className={styles.headerTxtSpan}>
                        <p className={styles.advancedP}>Generate</p>
                        <p className={styles.searchP}>Playlist</p>
                      </span>
                    </b>
                    <div className={styles.subheadDiv}>
                      Get new jams based on your favorite songs
                    </div>
                  </div>
                </div>
                <div className={styles.frame811340Div}>
                  <div
                    className={styles.button7Div}
                    onClick={onButton7ContainerClick}
                  >
                    <button className={styles.statelayerButton}>
                      <img className={styles.icons} alt="" src="icons.svg" />
                    </button>
                  </div>
                </div>
              </div>
              <img
                className={styles.frameIcon1}
                alt=""
                src="frame-8113081.svg"
              />
            </div>
            <div className={styles.horizontalcard2Div}>
              <div className={styles.contentDiv}>
                <div className={styles.text2Div}>
                  <b className={styles.headerB}>
                    <span className={styles.headerTxtSpan}>
                      <p className={styles.advancedP}>Database</p>
                    </span>
                  </b>
                  <div className={styles.subhead2Div}>browse the library</div>
                </div>
                <div className={styles.frame811340Div}>
                  <a className={styles.button6A} href="/database">
                    <button className={styles.statelayerButton}>
                      <img className={styles.icons} alt="" src="icons.svg" />
                    </button>
                  </a>
                </div>
              </div>
              <img
                className={styles.frame811308Icon}
                alt=""
                src="frame-8113082.svg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
